from flask import Flask, render_template
import random

app = Flask(__name__)

# Sample categories
CATEGORIES = ['Lunch', 'Dinner', 'Sushi', 'Dessert', 'Breakfast']

@app.route('/')
def home():
    # Randomly select a category
    random_category = random.choice(CATEGORIES)
    # Pass the random category to the front-end
    return render_template('home.html', randomCategoryShortName=random_category)

if __name__ == '__main__':
    app.run(debug=True)
